package com.example.todoJavaBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoJavaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoJavaBackendApplication.class, args);
	}

}
